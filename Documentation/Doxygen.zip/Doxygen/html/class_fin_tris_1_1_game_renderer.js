var class_fin_tris_1_1_game_renderer =
[
    [ "GameRenderer", "class_fin_tris_1_1_game_renderer.html#a6b4f2e9f5eb266cd08e86d80dbe8047a", null ],
    [ "CheatCode", "class_fin_tris_1_1_game_renderer.html#ae0e2916214f743322f63b07fa12351c1", null ],
    [ "DeathAnim", "class_fin_tris_1_1_game_renderer.html#ae21ee2ad0d23020717755106d25a832a", null ],
    [ "Refresh", "class_fin_tris_1_1_game_renderer.html#a2508fb1e33fa27cd94fb3d73c772eead", null ]
];