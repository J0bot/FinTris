var class_fin_tris_1_1_menu =
[
    [ "Menu", "class_fin_tris_1_1_menu.html#ac7e87e95950c5517bbef6cf9868b4e32", null ],
    [ "Add", "class_fin_tris_1_1_menu.html#a21bb0e45f0f174b5655546b6a0b8acab", null ],
    [ "ShowMenu", "class_fin_tris_1_1_menu.html#ac454ccf3d3eda1876d1818a28ae753a7", null ],
    [ "SelectedOption", "class_fin_tris_1_1_menu.html#a8464b8560839724d7439b7fe79821311", null ]
];