var struct_fin_tris_1_1_vector2 =
[
    [ "Vector2", "struct_fin_tris_1_1_vector2.html#a413d964f3f4dfd3f8d2f168b054202ad", null ],
    [ "x", "struct_fin_tris_1_1_vector2.html#a891b7cc1653a4241465d93abfb4631f7", null ],
    [ "y", "struct_fin_tris_1_1_vector2.html#ab48634330ae963bf99b38b62ff56be6d", null ]
];