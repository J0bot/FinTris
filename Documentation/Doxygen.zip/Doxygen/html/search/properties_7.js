var searchData=
[
  ['rows_174',['Rows',['../class_fin_tris_1_1_game.html#a8390b9ddca1eaa8216782708566a1d17',1,'FinTris::Game']]],
  ['rowscleared_175',['RowsCleared',['../class_fin_tris_1_1_game.html#ab9c4706e995a3c22c2ce8c87050db0a1',1,'FinTris::Game']]]
];
