var searchData=
[
  ['blocks_162',['Blocks',['../class_fin_tris_1_1_tetromino.html#a5382e79433b945bcd4bc928c9553fb78',1,'FinTris::Tetromino']]],
  ['board_163',['Board',['../class_fin_tris_1_1_game.html#a66c0019816b1f0ba6f52570cbe832602',1,'FinTris::Game']]]
];
