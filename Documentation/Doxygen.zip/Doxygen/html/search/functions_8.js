var searchData=
[
  ['showmenu_121',['ShowMenu',['../class_fin_tris_1_1_menu.html#ac454ccf3d3eda1876d1818a28ae753a7',1,'FinTris::Menu']]],
  ['speedup_122',['SpeedUp',['../class_fin_tris_1_1_game.html#ab5fa1b3c235dd14093f6ec28db151d12',1,'FinTris::Game']]],
  ['start_123',['Start',['../class_fin_tris_1_1_game.html#a7d9fbc9c0a2500dd630078e997c8a5b8',1,'FinTris::Game']]],
  ['stop_124',['Stop',['../class_fin_tris_1_1_game.html#a7cb1fa3bbdc3d9142377e151e75238f0',1,'FinTris::Game']]]
];
