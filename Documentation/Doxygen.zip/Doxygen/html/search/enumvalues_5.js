var searchData=
[
  ['nexttetromino_153',['NextTetromino',['../namespace_fin_tris.html#a61072f9affff5ce79fe8a4e4bc0120e8a89a21189e4197377beda7329dcbc3be3',1,'FinTris']]]
];
