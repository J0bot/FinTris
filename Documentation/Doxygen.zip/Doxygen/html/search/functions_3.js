var searchData=
[
  ['game_104',['Game',['../class_fin_tris_1_1_game.html#a5b440c8ea348561f43c3785fe3cca64f',1,'FinTris::Game']]],
  ['gamerenderer_105',['GameRenderer',['../class_fin_tris_1_1_game_renderer.html#a6b4f2e9f5eb266cd08e86d80dbe8047a',1,'FinTris::GameRenderer']]]
];
