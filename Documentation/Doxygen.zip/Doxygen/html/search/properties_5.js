var searchData=
[
  ['nexttetromino_171',['NextTetromino',['../class_fin_tris_1_1_game.html#a6b3c7939c2b14a320d8f25b88534c0b6',1,'FinTris::Game']]]
];
