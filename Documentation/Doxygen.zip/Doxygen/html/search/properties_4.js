var searchData=
[
  ['level_170',['Level',['../class_fin_tris_1_1_game.html#ae7b233dd224ba42a245140e341588c47',1,'FinTris::Game']]]
];
