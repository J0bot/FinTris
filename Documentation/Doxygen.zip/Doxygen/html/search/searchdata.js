var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvwxyz",
  1: "fgmprtv",
  2: "f",
  3: "acdgmoprstvw",
  4: "dfloruxyz",
  5: "gst",
  6: "efilmnpsw",
  7: "bchilnprstw",
  8: "nrst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties",
  8: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties",
  8: "Events"
};

