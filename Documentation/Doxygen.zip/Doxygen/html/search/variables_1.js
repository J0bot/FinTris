var searchData=
[
  ['fontfamily_130',['FontFamily',['../struct_fin_tris_1_1_console_helper_1_1_font_info.html#aea0f1ee8da77f42a2eb3375aa26d88f3',1,'FinTris::ConsoleHelper::FontInfo']]],
  ['fontname_131',['FontName',['../struct_fin_tris_1_1_console_helper_1_1_font_info.html#ac487d22817d02d4a11187c3a3506d6aa',1,'FinTris::ConsoleHelper::FontInfo']]],
  ['fontsize_132',['FontSize',['../struct_fin_tris_1_1_console_helper_1_1_font_info.html#a225c948edcb867304b1ee688a15117e2',1,'FinTris::ConsoleHelper::FontInfo']]],
  ['fontweight_133',['FontWeight',['../struct_fin_tris_1_1_console_helper_1_1_font_info.html#a02c7ac68929d85e01ed0f119f8911ad3',1,'FinTris::ConsoleHelper::FontInfo']]]
];
