var searchData=
[
  ['resources_96',['Resources',['../class_fin_tris_1_1_properties_1_1_resources.html',1,'FinTris::Properties::Resources'],['../class_fin_tris_1_1_resources.html',1,'FinTris::Resources']]]
];
