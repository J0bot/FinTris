var searchData=
[
  ['id_168',['Id',['../class_fin_tris_1_1_menu_entry.html#a720243943f5e1af518e414c43c25745f',1,'FinTris::MenuEntry']]],
  ['isselected_169',['IsSelected',['../class_fin_tris_1_1_menu_entry.html#a5f3c8f021e63a011b4a1602a33b68755',1,'FinTris::MenuEntry']]]
];
