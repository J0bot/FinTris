var searchData=
[
  ['color_164',['Color',['../class_fin_tris_1_1_tetromino.html#aeecfbc893f0380e6aceb2c9e17e06336',1,'FinTris::Tetromino']]],
  ['columns_165',['Columns',['../class_fin_tris_1_1_game.html#a00e9e94bba745cf2c12e3dc653eee656',1,'FinTris::Game']]],
  ['currenttetromino_166',['CurrentTetromino',['../class_fin_tris_1_1_game.html#a492fa70e80fe35395af550411f245d11',1,'FinTris::Game']]]
];
