var searchData=
[
  ['nexttetrospawned_183',['NextTetroSpawned',['../class_fin_tris_1_1_game.html#a63e2be39bc40105119f07dc09ecd3afb',1,'FinTris::Game']]]
];
