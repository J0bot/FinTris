var searchData=
[
  ['text_181',['Text',['../class_fin_tris_1_1_menu_entry.html#a3ab56fd30621f539b9ecca50e5ddc481',1,'FinTris::MenuEntry']]]
];
