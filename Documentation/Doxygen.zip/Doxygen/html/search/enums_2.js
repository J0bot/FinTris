var searchData=
[
  ['tetrominostate_143',['TetrominoState',['../namespace_fin_tris.html#a61072f9affff5ce79fe8a4e4bc0120e8',1,'FinTris']]],
  ['tetrominotype_144',['TetrominoType',['../namespace_fin_tris.html#a9533932b81fbf924c6f935c27ae016a9',1,'FinTris']]]
];
