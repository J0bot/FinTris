var searchData=
[
  ['add_100',['Add',['../class_fin_tris_1_1_menu.html#a21bb0e45f0f174b5655546b6a0b8acab',1,'FinTris::Menu']]]
];
