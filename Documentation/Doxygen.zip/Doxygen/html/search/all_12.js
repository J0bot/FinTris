var searchData=
[
  ['vector2_83',['Vector2',['../struct_fin_tris_1_1_vector2.html',1,'FinTris.Vector2'],['../struct_fin_tris_1_1_vector2.html#a413d964f3f4dfd3f8d2f168b054202ad',1,'FinTris.Vector2.Vector2()']]]
];
