var searchData=
[
  ['pause_115',['Pause',['../class_fin_tris_1_1_game.html#a2eccd2753e8375c47d5218110c104933',1,'FinTris::Game']]],
  ['pauseorresume_116',['PauseOrResume',['../class_fin_tris_1_1_game.html#a1c919302051a6e446b755bb6670de726',1,'FinTris::Game']]]
];
