var searchData=
[
  ['game_91',['Game',['../class_fin_tris_1_1_game.html',1,'FinTris']]],
  ['gamerenderer_92',['GameRenderer',['../class_fin_tris_1_1_game_renderer.html',1,'FinTris']]]
];
