var searchData=
[
  ['refresh_52',['Refresh',['../class_fin_tris_1_1_game_renderer.html#a2508fb1e33fa27cd94fb3d73c772eead',1,'FinTris::GameRenderer']]],
  ['renderoption_53',['RenderOption',['../class_fin_tris_1_1_menu_entry.html#a5ce95d8ace0a88b6f6061e2ee9591098',1,'FinTris::MenuEntry']]],
  ['resources_54',['Resources',['../class_fin_tris_1_1_properties_1_1_resources.html',1,'FinTris::Properties::Resources'],['../class_fin_tris_1_1_resources.html',1,'FinTris::Resources']]],
  ['resume_55',['Resume',['../class_fin_tris_1_1_game.html#addff7e831dc739f3e80357fd0f6e4d66',1,'FinTris::Game']]],
  ['right_56',['Right',['../struct_fin_tris_1_1_vector2.html#ac9ebb52718719169352303acf13954b5',1,'FinTris::Vector2']]],
  ['rotate_57',['Rotate',['../class_fin_tris_1_1_game.html#a07adff961d5daab018d4bfd133622c6d',1,'FinTris.Game.Rotate()'],['../class_fin_tris_1_1_tetromino.html#a42183d3129a23c7c5cc841d98e18ad9b',1,'FinTris.Tetromino.Rotate()']]],
  ['rowcleared_58',['RowCleared',['../class_fin_tris_1_1_game.html#a61b9d3af2341e461b83a6211f8bc5f6d',1,'FinTris::Game']]],
  ['rows_59',['Rows',['../class_fin_tris_1_1_game.html#a8390b9ddca1eaa8216782708566a1d17',1,'FinTris::Game']]],
  ['rowscleared_60',['RowsCleared',['../class_fin_tris_1_1_game.html#ab9c4706e995a3c22c2ce8c87050db0a1',1,'FinTris::Game']]]
];
