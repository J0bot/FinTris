var searchData=
[
  ['pause_44',['Pause',['../class_fin_tris_1_1_game.html#a2eccd2753e8375c47d5218110c104933',1,'FinTris::Game']]],
  ['paused_45',['Paused',['../namespace_fin_tris.html#adfcd702ffca943d7876e851313cc957fae99180abf47a8b3a856e0bcb2656990a',1,'FinTris']]],
  ['pauseorresume_46',['PauseOrResume',['../class_fin_tris_1_1_game.html#a1c919302051a6e446b755bb6670de726',1,'FinTris::Game']]],
  ['playing_47',['Playing',['../namespace_fin_tris.html#adfcd702ffca943d7876e851313cc957fac9dbb2b7c84159b632d71e512eba8428',1,'FinTris']]],
  ['position_48',['Position',['../class_fin_tris_1_1_tetromino.html#a24932ff9e29e39fb41e5d406257e9512',1,'FinTris::Tetromino']]],
  ['previousposition_49',['PreviousPosition',['../class_fin_tris_1_1_tetromino.html#aef5f974c4dc8cd43c6c61a295f2520b1',1,'FinTris::Tetromino']]],
  ['program_50',['Program',['../class_fin_tris_1_1_program.html',1,'FinTris']]],
  ['pyramid_51',['Pyramid',['../namespace_fin_tris.html#a9533932b81fbf924c6f935c27ae016a9a5e5b0d93bab61584149905b5e5dc71a0',1,'FinTris']]]
];
