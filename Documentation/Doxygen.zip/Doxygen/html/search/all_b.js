var searchData=
[
  ['nexttetromino_38',['NextTetromino',['../class_fin_tris_1_1_game.html#a6b3c7939c2b14a320d8f25b88534c0b6',1,'FinTris.Game.NextTetromino()'],['../namespace_fin_tris.html#a61072f9affff5ce79fe8a4e4bc0120e8a89a21189e4197377beda7329dcbc3be3',1,'FinTris.NextTetromino()']]],
  ['nexttetrospawned_39',['NextTetroSpawned',['../class_fin_tris_1_1_game.html#a63e2be39bc40105119f07dc09ecd3afb',1,'FinTris::Game']]]
];
