var searchData=
[
  ['height_167',['Height',['../class_fin_tris_1_1_tetromino.html#ab0c1e7dd3a97bc9733fa69e4e598d472',1,'FinTris::Tetromino']]]
];
