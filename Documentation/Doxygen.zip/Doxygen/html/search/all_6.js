var searchData=
[
  ['game_18',['Game',['../class_fin_tris_1_1_game.html',1,'FinTris.Game'],['../class_fin_tris_1_1_game.html#a5b440c8ea348561f43c3785fe3cca64f',1,'FinTris.Game.Game()']]],
  ['gamerenderer_19',['GameRenderer',['../class_fin_tris_1_1_game_renderer.html',1,'FinTris.GameRenderer'],['../class_fin_tris_1_1_game_renderer.html#a6b4f2e9f5eb266cd08e86d80dbe8047a',1,'FinTris.GameRenderer.GameRenderer()']]],
  ['gamestate_20',['GameState',['../namespace_fin_tris.html#adfcd702ffca943d7876e851313cc957f',1,'FinTris']]]
];
