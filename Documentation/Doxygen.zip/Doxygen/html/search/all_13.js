var searchData=
[
  ['waiting_84',['Waiting',['../namespace_fin_tris.html#adfcd702ffca943d7876e851313cc957fa5706de961fb376d701be6e7762d8b09c',1,'FinTris']]],
  ['width_85',['Width',['../class_fin_tris_1_1_tetromino.html#a6405cbd0a02804e65bce3246945b6b5b',1,'FinTris::Tetromino']]],
  ['withinrange_86',['WithinRange',['../class_fin_tris_1_1_game.html#a6565e59a51ff9383e0292395856f5ae6',1,'FinTris::Game']]]
];
