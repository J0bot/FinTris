var files_dup =
[
    [ "FinTris", "dir_20844d5716a0bca1fbfffca524d38536.html", "dir_20844d5716a0bca1fbfffca524d38536" ]
];