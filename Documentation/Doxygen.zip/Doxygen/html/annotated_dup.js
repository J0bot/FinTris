var annotated_dup =
[
    [ "FinTris", "namespace_fin_tris.html", "namespace_fin_tris" ]
];