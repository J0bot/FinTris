var class_fin_tris_1_1_tetromino =
[
    [ "Tetromino", "class_fin_tris_1_1_tetromino.html#a03d7429ee2ec220a00f169732ba27455", null ],
    [ "Move", "class_fin_tris_1_1_tetromino.html#a4bdb715cbdbd6e948424b2dfd780c278", null ],
    [ "Rotate", "class_fin_tris_1_1_tetromino.html#a42183d3129a23c7c5cc841d98e18ad9b", null ],
    [ "Blocks", "class_fin_tris_1_1_tetromino.html#a5382e79433b945bcd4bc928c9553fb78", null ],
    [ "Color", "class_fin_tris_1_1_tetromino.html#aeecfbc893f0380e6aceb2c9e17e06336", null ],
    [ "Height", "class_fin_tris_1_1_tetromino.html#ab0c1e7dd3a97bc9733fa69e4e598d472", null ],
    [ "Position", "class_fin_tris_1_1_tetromino.html#a24932ff9e29e39fb41e5d406257e9512", null ],
    [ "PreviousPosition", "class_fin_tris_1_1_tetromino.html#aef5f974c4dc8cd43c6c61a295f2520b1", null ],
    [ "Shape", "class_fin_tris_1_1_tetromino.html#a723d4e46fd351b79a9a3d96f9a60e420", null ],
    [ "State", "class_fin_tris_1_1_tetromino.html#ab64f47ff789a29de8a1326469fa4c24e", null ],
    [ "Width", "class_fin_tris_1_1_tetromino.html#a6405cbd0a02804e65bce3246945b6b5b", null ]
];