var namespaces_dup =
[
    [ "FinTris", "namespace_fin_tris.html", null ]
];