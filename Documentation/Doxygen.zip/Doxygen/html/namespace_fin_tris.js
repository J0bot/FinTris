var namespace_fin_tris =
[
    [ "Properties", null, [
      [ "Resources", "class_fin_tris_1_1_properties_1_1_resources.html", null ]
    ] ],
    [ "Game", "class_fin_tris_1_1_game.html", "class_fin_tris_1_1_game" ],
    [ "GameRenderer", "class_fin_tris_1_1_game_renderer.html", "class_fin_tris_1_1_game_renderer" ],
    [ "Menu", "class_fin_tris_1_1_menu.html", "class_fin_tris_1_1_menu" ],
    [ "MenuEntry", "class_fin_tris_1_1_menu_entry.html", "class_fin_tris_1_1_menu_entry" ],
    [ "Program", "class_fin_tris_1_1_program.html", null ],
    [ "Resources", "class_fin_tris_1_1_resources.html", null ],
    [ "Tetromino", "class_fin_tris_1_1_tetromino.html", "class_fin_tris_1_1_tetromino" ],
    [ "Vector2", "struct_fin_tris_1_1_vector2.html", "struct_fin_tris_1_1_vector2" ]
];