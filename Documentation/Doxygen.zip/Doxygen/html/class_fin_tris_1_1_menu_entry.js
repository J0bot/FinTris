var class_fin_tris_1_1_menu_entry =
[
    [ "MenuEntry", "class_fin_tris_1_1_menu_entry.html#a96ff56f0c708ed65e928695d40cdca9e", null ],
    [ "MenuEntry", "class_fin_tris_1_1_menu_entry.html#a06d284855e207b0208ee0ef2a0f4102b", null ],
    [ "RenderOption", "class_fin_tris_1_1_menu_entry.html#a5ce95d8ace0a88b6f6061e2ee9591098", null ],
    [ "ToString", "class_fin_tris_1_1_menu_entry.html#a7261a2e6a2e132c6585bdb6fe1e33875", null ],
    [ "Id", "class_fin_tris_1_1_menu_entry.html#a720243943f5e1af518e414c43c25745f", null ],
    [ "IsSelected", "class_fin_tris_1_1_menu_entry.html#a5f3c8f021e63a011b4a1602a33b68755", null ],
    [ "Suffix", "class_fin_tris_1_1_menu_entry.html#aaa1d613c46431ff5e423ba1abf6444a2", null ],
    [ "Text", "class_fin_tris_1_1_menu_entry.html#a3ab56fd30621f539b9ecca50e5ddc481", null ]
];