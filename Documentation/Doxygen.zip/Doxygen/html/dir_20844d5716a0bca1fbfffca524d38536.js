var dir_20844d5716a0bca1fbfffca524d38536 =
[
    [ "Enums", "dir_f3f1e787bee6a96ccda5dc243f36395b.html", "dir_f3f1e787bee6a96ccda5dc243f36395b" ],
    [ "obj", "dir_0a1de49a61f8504745144b19b5094b1e.html", "dir_0a1de49a61f8504745144b19b5094b1e" ],
    [ "Properties", "dir_6cb93b4f13ff6ec5f0d618b9bf018256.html", "dir_6cb93b4f13ff6ec5f0d618b9bf018256" ],
    [ "Structs", "dir_0fc60452c78a949c735184e245f6fcc4.html", "dir_0fc60452c78a949c735184e245f6fcc4" ],
    [ "UI", "dir_3e1a833aca5ac7eab9cc1d424d64a6de.html", "dir_3e1a833aca5ac7eab9cc1d424d64a6de" ],
    [ "Config.cs", "_config_8cs_source.html", null ],
    [ "ConsoleHelper.cs", "_console_helper_8cs_source.html", null ],
    [ "Game.cs", "_game_8cs_source.html", null ],
    [ "GameManager.cs", "_game_manager_8cs_source.html", null ],
    [ "GameRenderer.cs", "_game_renderer_8cs_source.html", null ],
    [ "Program.cs", "_program_8cs_source.html", null ],
    [ "Resources.Designer.cs", "_resources_8_designer_8cs_source.html", null ],
    [ "Tetromino.cs", "_tetromino_8cs_source.html", null ]
];